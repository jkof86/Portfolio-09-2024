// ------------------------------------------------------------
// ✅ IMPORTS
// node-fetch → allows server-side HTTP requests
// xml2js → converts RSS/Atom XML into JSON
// ------------------------------------------------------------
import fetch from "node-fetch";
import { parseStringPromise } from "xml2js";

// ------------------------------------------------------------
// ✅ FEED MAP
// Maps ?source= values to actual RSS/Atom URLs
// ------------------------------------------------------------
const FEEDS = {
  coinbase: "https://blog.coinbase.com/feed",
  coindesk: "https://www.coindesk.com/arc/outboundfeeds/rss/",
  cointelegraph: "https://cointelegraph.com/rss",
  javacodegeeks: "https://www.javacodegeeks.com/feed"
};

// ------------------------------------------------------------
// ✅ MAIN LAMBDA HANDLER
// This function runs every time your frontend calls the API.
// ------------------------------------------------------------
export const handler = async (event) => {
  try {
    // --------------------------------------------------------
    // ✅ Extract ?source= parameter from the request
    // Example: /feed?source=coinbase
    // --------------------------------------------------------
    const source = event.queryStringParameters?.source;
    const feedUrl = FEEDS[source];

    // --------------------------------------------------------
    // ✅ Validate feed source
    // --------------------------------------------------------
    if (!feedUrl) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "Invalid source" })
      };
    }

    // --------------------------------------------------------
    // ✅ Fetch the RSS/Atom XML from the real feed
    // This is server-side, so Cloudflare cannot block it.
    // --------------------------------------------------------
    const xmlResponse = await fetch(feedUrl);
    const xml = await xmlResponse.text();

    // --------------------------------------------------------
    // ✅ Convert XML → JSON using xml2js
    // --------------------------------------------------------
    const parsed = await parseStringPromise(xml, { explicitArray: false });

    // --------------------------------------------------------
    // ✅ Extract the feed items
    // RSS uses: rss.channel.item
    // Atom uses: feed.entry
    // --------------------------------------------------------
    const channel = parsed.rss?.channel || parsed.feed;
    const rawItems = channel.item || channel.entry || [];

    // --------------------------------------------------------
    // ✅ Normalize items into a consistent JSON structure
    // to ensures frontend never has to guess field names.
    // --------------------------------------------------------
    const items = (Array.isArray(rawItems) ? rawItems : [rawItems]).map(item => ({
      title: item.title?._ || item.title || "",
      url: item.link?.href || item.link || item.id || "",
      date_published: item.pubDate || item.published || "",
      summary: item.description || item.summary?._ || "",
      content_html: item["content:encoded"] || item.content?._ || "",
      image: item.enclosure?.url || null
    }));

    // --------------------------------------------------------
    // ✅ Return normalized JSON with CORS headers
    // --------------------------------------------------------
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ items })
    };

  } catch (err) {
    // --------------------------------------------------------
    // ✅ Error handling
    // --------------------------------------------------------
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        error: "Error processing feed",
        details: err.message
      })
    };
  }
};